public class DuplicateSymException extends Exception {

}
